"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("../../internal/tslib.js");
tslib_1.__exportStar(require("./skills/index.js"), exports);
//# sourceMappingURL=skills.js.map