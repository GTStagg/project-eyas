"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Batches = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const tracing_1 = require("../../internal/tracing.js");
const jsonl_1 = require("../../internal/decoders/jsonl.js");
const error_1 = require("../../error.js");
const path_1 = require("../../internal/utils/path.js");
class Batches extends resource_1.APIResource {
    /**
     * Send a batch of Message creation requests.
     *
     * The Message Batches API can be used to process multiple Messages API requests at
     * once. Once a Message Batch is created, it begins processing immediately. Batches
     * can take up to 24 hours to complete.
     *
     * Learn more about the Message Batches API in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
     *
     * @example
     * ```ts
     * const messageBatch = await client.messages.batches.create({
     *   requests: [
     *     {
     *       custom_id: 'my-custom-id-1',
     *       params: {
     *         max_tokens: 1024,
     *         messages: [
     *           { content: 'Hello, world', role: 'user' },
     *         ],
     *         model: 'claude-opus-5-5',
     *       },
     *     },
     *   ],
     * });
     * ```
     */
    create(params, options) {
        const { user_profile_id, workspace_id, ...body } = params;
        return this._client.post('/v1/messages/batches', {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    ...(user_profile_id != null ? { 'anthropic-user-profile-id': user_profile_id } : undefined),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.messages.batches.create', options, {
                route: '/v1/messages/batches',
                // A request without `requests` is for the API to refuse, not for this line to throw on.
                attributes: { 'anthropic.message.batch.request_count': body.requests?.length },
                createdIDAttribute: 'anthropic.message.batch.id',
            }),
        });
    }
    /**
     * This endpoint is idempotent and can be used to poll for Message Batch
     * completion. To access the results of a Message Batch, make a request to the
     * `results_url` field in the response.
     *
     * Learn more about the Message Batches API in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
     *
     * @example
     * ```ts
     * const messageBatch = await client.messages.batches.retrieve(
     *   'message_batch_id',
     * );
     * ```
     */
    retrieve(messageBatchID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.get((0, path_1.path) `/v1/messages/batches/${messageBatchID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined) },
                options?.headers,
            ]),
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.messages.batches.retrieve', options, {
                route: '/v1/messages/batches/{message_batch_id}',
                attributes: { 'anthropic.message.batch.id': messageBatchID },
            }),
        });
    }
    /**
     * List all Message Batches within a Workspace. Most recently created batches are
     * returned first.
     *
     * Learn more about the Message Batches API in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const messageBatch of client.messages.batches.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
        const { workspace_id, ...query } = params ?? {};
        return this._client.getAPIList('/v1/messages/batches', (pagination_1.Page), {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined) },
                options?.headers,
            ]),
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.messages.batches.list', options, {
                route: '/v1/messages/batches',
                queryParams: ['after_id', 'before_id', 'limit'],
            }),
        });
    }
    /**
     * Delete a Message Batch.
     *
     * Message Batches can only be deleted once they've finished processing. If you'd
     * like to delete an in-progress batch, you must first cancel it.
     *
     * Learn more about the Message Batches API in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
     *
     * @example
     * ```ts
     * const deletedMessageBatch =
     *   await client.messages.batches.delete('message_batch_id');
     * ```
     */
    delete(messageBatchID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.delete((0, path_1.path) `/v1/messages/batches/${messageBatchID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined) },
                options?.headers,
            ]),
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.messages.batches.delete', options, {
                route: '/v1/messages/batches/{message_batch_id}',
                attributes: { 'anthropic.message.batch.id': messageBatchID },
            }),
        });
    }
    /**
     * Batches may be canceled any time before processing ends. Once cancellation is
     * initiated, the batch enters a `canceling` state, at which time the system may
     * complete any in-progress, non-interruptible requests before finalizing
     * cancellation.
     *
     * The number of canceled requests is specified in `request_counts`. To determine
     * which requests were canceled, check the individual results within the batch.
     * Note that cancellation may not result in any canceled requests if they were
     * non-interruptible.
     *
     * Learn more about the Message Batches API in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
     *
     * @example
     * ```ts
     * const messageBatch = await client.messages.batches.cancel(
     *   'message_batch_id',
     * );
     * ```
     */
    cancel(messageBatchID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.post((0, path_1.path) `/v1/messages/batches/${messageBatchID}/cancel`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined) },
                options?.headers,
            ]),
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.messages.batches.cancel', options, {
                route: '/v1/messages/batches/{message_batch_id}/cancel',
                attributes: { 'anthropic.message.batch.id': messageBatchID },
            }),
        });
    }
    /**
     * Streams the results of a Message Batch as a `.jsonl` file.
     *
     * Each line in the file is a JSON object containing the result of a single request
     * in the Message Batch. Results are not guaranteed to be in the same order as
     * requests. Use the `custom_id` field to match results to requests.
     *
     * Learn more about the Message Batches API in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
     *
     * @example
     * ```ts
     * const stream = await client.messages.batches.results(
     *   'message_batch_id',
     * );
     * for await (const messageBatchIndividualResponse of stream) {
     *   // ...
     * }
     * ```
     */
    async results(messageBatchID, params = {}, options) {
        const batch = await this.retrieve(messageBatchID, params, options);
        if (!batch.results_url) {
            throw new error_1.AnthropicError(`No batch \`results_url\`; Has it finished processing? ${batch.processing_status} - ${batch.id}`);
        }
        const { workspace_id } = params ?? {};
        return this._client
            .get(batch.results_url, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    Accept: 'application/binary',
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            stream: true,
            __binaryResponse: true,
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.messages.batches.results', options, {
                route: '/v1/messages/batches/{message_batch_id}/results',
                attributes: { 'anthropic.message.batch.id': messageBatchID },
            }),
        })
            ._thenUnwrap((_, props) => jsonl_1.JSONLDecoder.fromResponse(props.response, props.controller));
    }
}
exports.Batches = Batches;
//# sourceMappingURL=batches.js.map