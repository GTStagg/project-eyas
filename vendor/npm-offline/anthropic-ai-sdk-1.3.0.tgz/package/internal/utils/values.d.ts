export declare const isAbsoluteURL: (url: string) => boolean;
export declare let isArray: (val: unknown) => val is unknown[];
export declare let isReadonlyArray: (val: unknown) => val is readonly unknown[];
/** Returns an object if the given value isn't an object, otherwise returns as-is */
export declare function maybeObj(x: unknown): object;
export declare function isEmptyObj(obj: Object | null | undefined): boolean;
export declare function hasOwn<T extends object = object>(obj: T, key: PropertyKey): key is keyof T;
export declare function isObj(obj: unknown): obj is Record<string, unknown>;
export declare const ensurePresent: <T>(value: T | null | undefined) => T;
export declare const validatePositiveInteger: (name: string, n: unknown) => number;
export declare const CREDENTIAL_OPTIONS: readonly ["apiKey", "authToken", "credentials", "config", "profile"];
export type CredentialOption = (typeof CREDENTIAL_OPTIONS)[number];
export type PlatformCredentials = {
    /** The first-party credential options the platform client takes. It rejects the rest. */
    accepts: readonly CredentialOption[];
    unsupportedOptionMessage: (option: CredentialOption) => string;
};
/**
 * Throws when `options` holds a first-party credential option that a platform
 * client does not accept, so that a new one is rejected until the client opts
 * in. `null` passes, because the base `withOptions` fills the credential
 * options it clears with `null`.
 */
export declare const rejectUnsupportedCredentials: (options: object, platform: PlatformCredentials) => void;
export declare const coerceInteger: (value: unknown) => number;
export declare const coerceFloat: (value: unknown) => number;
export declare const coerceBoolean: (value: unknown) => boolean;
export declare const maybeCoerceInteger: (value: unknown) => number | undefined;
export declare const maybeCoerceFloat: (value: unknown) => number | undefined;
export declare const maybeCoerceBoolean: (value: unknown) => boolean | undefined;
export declare const safeJSON: (text: string) => any;
export declare const pop: <T extends Record<string, any>, K extends string>(obj: T, key: K) => T[K];
/**
 * Compile-time exhaustiveness check: passing a value here only type-checks once every
 * member of its union has been handled. Does nothing at runtime, so unknown values from a
 * newer API version fall through instead of throwing.
 */
export declare function checkNever(_value: never): void;
//# sourceMappingURL=values.d.ts.map