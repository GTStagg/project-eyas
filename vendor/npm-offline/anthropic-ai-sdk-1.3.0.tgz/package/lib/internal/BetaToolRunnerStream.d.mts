import type { Anthropic } from "../../client.mjs";
import type { BetaMessage, BetaRawMessageStreamEvent, BetaToolUseBlock, MessageCreateParamsBase } from "../../resources/beta/messages/messages.mjs";
import { BetaMessageStream } from "../BetaMessageStream.mjs";
/**
 * The stream a tool runner yields. It hands each `tool_use` call to `onToolCall` once the model has moved on
 * from it, and the caller's listeners and `for await` loops over the stream have handled the event that shows it.
 */
export declare class BetaToolRunnerStream extends BetaMessageStream {
    #private;
    constructor(params: MessageCreateParamsBase, onToolCall: (toolUse: BetaToolUseBlock) => void, client: Anthropic);
    /** The `tool_use` blocks that have finished streaming, in the model's order */
    get toolCalls(): readonly BetaToolUseBlock[];
    protected _deliverEvent(event: BetaRawMessageStreamEvent, snapshot: BetaMessage | undefined): void;
    [Symbol.asyncIterator](): AsyncIterator<BetaRawMessageStreamEvent>;
}
//# sourceMappingURL=BetaToolRunnerStream.d.mts.map