import type { BetaMessageParam } from "../../../resources/beta/messages/messages.mjs";
import type { BetaMessageThreadFields } from "../../threads/params.mjs";
import type { BetaToolRunnerParams, BetaToolRunnerSettings } from "../../tools/BetaToolRunner.mjs";
/**
 * `params` split into the runner's own settings, the `thread` choice, and the params of the thread it runs over. Throws
 * on a `thread` the params type leaves out.
 */
export declare function splitToolRunnerParams(params: BetaToolRunnerParams): {
    settings: BetaToolRunnerSettings;
    thread: BetaToolRunnerParams['thread'];
    threadParams: BetaMessageThreadFields & {
        messages: BetaMessageParam[];
    };
};
//# sourceMappingURL=tool-runner-params.d.mts.map