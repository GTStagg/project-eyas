import type { Anthropic } from "../client.js";
import { type StainlessHelperHeaderValue } from "../internal/stainless-helper-header.js";
/**
 * Return a `withOptions()` clone of `client` set up for use *by* one of the
 * runner helpers: authenticated with `authToken` as Bearer credentials in
 * place of the parent's own credential, and tagged with the helper's
 * `x-stainless-helper` value on every outgoing request.
 *
 * The returned sub-client inherits the parent's full configuration
 * (`baseURL`, `timeout`, `maxRetries`, `fetch`, `fetchOptions`, custom
 * `defaultHeaders`, `defaultQuery`). Overrides applied:
 *
 * - `authToken: authToken` — the new credential, which replaces the parent's.
 * - `baseURL: client.baseURL` — pins the parent's resolved host (auth override otherwise resets it).
 * - `defaultHeaders` is rebuilt as `parent._authState.extraHeaders ⊕ parent.defaultHeaders ⊕
 *   {'x-stainless-helper': helper}`. `withOptions` *replaces* (does not
 *   merge) `defaultHeaders`, so we merge here so any custom headers the
 *   caller set on the parent client survive on the sub-client, except a
 *   hand-set `X-Api-Key` and a hand-set or omitted (`null`) `Authorization`.
 */
export declare function copyClientForHelper<T extends Anthropic>(client: T, { authToken, helper }: {
    authToken: string;
    helper: StainlessHelperHeaderValue;
}): T;
//# sourceMappingURL=helper-client.d.ts.map