import type { Anthropic } from "../../client.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import type { BetaMessage, BetaMessageParam } from "../../resources/beta/messages/messages.mjs";
import { type ParsedBetaMessage } from "../beta-parser.mjs";
import { BetaMessageStream } from "../BetaMessageStream.mjs";
import { BetaToolRunner, type BetaToolRunnerRequestOptions, type BetaToolRunnerSettings } from "../tools/BetaToolRunner.mjs";
import { type BetaMessageThreadCreateParams, type BetaMessageThreadInput, type BetaMessageThreadRequestOptions, type BetaMessageThreadSendParams } from "./params.mjs";
/** The params of `thread.toolRunner()`: the runner's own settings. Every other param is the thread's. */
export type BetaMessageThreadToolRunnerParams = BetaToolRunnerSettings;
export { type BetaMessageThreadCreateParams, type BetaMessageThreadFields, type BetaMessageThreadInput, type BetaMessageThreadRequestOptions, type BetaMessageThreadSendParams, type UnsupportedRequestBehavior, } from "./params.mjs";
/**
 * A conversation the server holds between turns, so each request sends only the new messages.
 *
 * Create one with `client.beta.messages.thread(...)`. A thread runs one turn at a time.
 */
export declare class BetaMessageThread<ParsedT = null> {
    /** Start a thread on `client` with the params of `client.beta.messages.thread()`. Sends nothing. */
    constructor(client: Anthropic, params: BetaMessageThreadCreateParams, options?: BetaMessageThreadRequestOptions);
    /** The full conversation, in a new array: every message the server holds plus those staged for the next turn. */
    get messages(): BetaMessageParam[];
    /** The response `id` the next turn continues from, or `null` when the next turn starts a new thread. */
    get previousMessageId(): string | null;
    /** The params of a `client.beta.messages.thread()` call for the whole conversation, in a new object. */
    get params(): BetaMessageThreadCreateParams & Required<Pick<BetaMessageThreadCreateParams, 'messages' | 'unsupportedRequestBehavior'>>;
    /** Stage messages for the next turn without sending anything. */
    append(...messages: Array<BetaMessageParam | BetaMessage>): void;
    /**
     * Send the staged messages and `messages` as one turn and resolve to the reply. `params` and `options` apply to this
     * turn only. Throws while another `send()` / `parse()` / `stream()` on this thread is in progress.
     */
    send(messages?: BetaMessageThreadInput, params?: BetaMessageThreadSendParams, options?: BetaMessageThreadRequestOptions): APIPromise<BetaMessage>;
    /**
     * Like `send()`, and parses the reply into `parsed_output` against the `output_config.format` (or `output_format`)
     * the thread was created with.
     */
    parse(messages?: BetaMessageThreadInput, params?: BetaMessageThreadSendParams, options?: BetaMessageThreadRequestOptions): APIPromise<ParsedBetaMessage<ParsedT>>;
    /** Like `send()`, and returns the reply's stream. The turn is in progress until the stream ends or is aborted. */
    stream(messages?: BetaMessageThreadInput, params?: BetaMessageThreadSendParams, options?: BetaMessageThreadRequestOptions): BetaMessageStream<ParsedT>;
    /**
     * Change the request fields and request options of all later turns without sending anything. `system` and `tools`
     * cannot change once a turn has created the thread.
     */
    update(params?: BetaMessageThreadSendParams, options?: BetaMessageThreadRequestOptions): void;
    /**
     * `client.beta.messages.toolRunner()` over this thread: call its runnable `tools` whenever the model asks for one,
     * until a reply makes no tool call. The replies and tool results become part of the thread's history.
     */
    toolRunner(params?: BetaMessageThreadToolRunnerParams & {
        stream?: false | undefined;
    }, options?: BetaToolRunnerRequestOptions): BetaToolRunner<false>;
    toolRunner(params: BetaMessageThreadToolRunnerParams & {
        stream: true;
    }, options?: BetaToolRunnerRequestOptions): BetaToolRunner<true>;
    toolRunner(params?: BetaMessageThreadToolRunnerParams, options?: BetaToolRunnerRequestOptions): BetaToolRunner<boolean>;
    /**
     * Return a new, independent thread with a copy of this one's history, request fields and request options, and no
     * `previousMessageId`. Sends nothing.
     */
    fork(): BetaMessageThread<ParsedT>;
}
//# sourceMappingURL=BetaMessageThread.d.mts.map