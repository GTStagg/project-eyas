import { BetaRunnableTool, Promisable } from "../../lib/tools/BetaRunnableTool.js";
import { BetaMemoryTool20250818, BetaMemoryTool20250818Command, BetaToolResultContentBlockParam } from "../../resources/beta.js";
type Command = BetaMemoryTool20250818Command['command'];
export type MemoryToolHandlers = {
    [K in Command]: (command: Extract<BetaMemoryTool20250818Command, {
        command: K;
    }>) => Promisable<string | Array<BetaToolResultContentBlockParam>>;
};
/**
 * @param extraProps Additional Claude API properties to include in the tool definition (e.g., `cache_control`)
 */
export declare function betaMemoryTool(handlers: MemoryToolHandlers, extraProps?: Omit<BetaMemoryTool20250818, 'type' | 'name'>): BetaRunnableTool<BetaMemoryTool20250818Command>;
export {};
//# sourceMappingURL=memory.d.ts.map