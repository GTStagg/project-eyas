/**
 * @param extraProps Additional Claude API properties to include in the tool definition (e.g., `cache_control`)
 */
export function betaMemoryTool(handlers, extraProps) {
    return {
        ...extraProps,
        type: 'memory_20250818',
        name: 'memory',
        parse: (content) => content,
        run: (args) => {
            const handler = handlers[args.command];
            if (!handler) {
                throw new Error(`${args.command} not implemented`);
            }
            return handler.bind(handlers)(args);
        },
    };
}
//# sourceMappingURL=memory.mjs.map