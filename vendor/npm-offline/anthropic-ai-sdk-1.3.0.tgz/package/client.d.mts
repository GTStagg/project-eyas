import type { RequestInit, RequestInfo } from "./internal/builtin-types.mjs";
import type { PromiseOrValue, MergedRequestInit, FinalizedRequestInit } from "./internal/types.mjs";
export type { Logger, LogLevel } from "./internal/utils/log.mjs";
import * as Opts from "./internal/request-options.mjs";
import { type OpenTelemetryOptions, type ResolvedOpenTelemetryOptions } from "./internal/tracing.mjs";
export type { OpenTelemetryOptions, OpenTelemetryRequestOptions, OpenTelemetryTracesOptions, ResolvedOpenTelemetryOptions, } from "./internal/tracing.mjs";
import * as Errors from "./core/error.mjs";
import type { AccessTokenProvider } from "./lib/credentials/types.mjs";
import type { AnthropicConfig } from "./core/credentials.mjs";
import { type Middleware } from "./core/middleware.mjs";
export type { Middleware, MiddlewareContext, MiddlewareNext } from "./core/middleware.mjs";
export type { APIRequest } from "./core/api.mjs";
import * as Pagination from "./core/pagination.mjs";
import { type BidirectionalPageCursor, type BidirectionalPageCursorParams, BidirectionalPageCursorResponse, type Page, type PageCursor, type PageCursorParams, PageCursorResponse, type PageParams, PageResponse, type ReportPageCursor, type ReportPageCursorParams, ReportPageCursorResponse, type TokenPage, type TokenPageParams, TokenPageResponse } from "./core/pagination.mjs";
import * as Uploads from "./core/uploads.mjs";
import * as API from "./resources/index.mjs";
import { APIPromise } from "./core/api-promise.mjs";
import { DeletedFile, FileDeleteParams, FileDownloadParams, FileListParams, FileMetadata, FileMetadataPageCursor, FileRetrieveMetadataParams, FileUploadParams, Files } from "./resources/files.mjs";
import { CapabilitySupport, ContextManagementCapability, EffortCapability, ModelCapabilities, ModelInfo, ModelInfosPage, ModelLine, ModelListParams, ModelRetrieveParams, Models, ServerToolsCapability, ThinkingCapability, ThinkingTypes } from "./resources/models.mjs";
import { AnthropicBeta, Beta, BetaAPIError, BetaAuthenticationError, BetaBillingError, BetaCurrency, BetaError, BetaErrorResponse, BetaGatewayTimeoutError, BetaInvalidRequestError, BetaMonetaryAmount, BetaNotFoundError, BetaOverloadedError, BetaPermissionError, BetaRateLimitError } from "./resources/beta/beta.mjs";
import { AssistantMessageParam, Base64ImageSource, Base64PDFSource, BashCodeExecutionOutputBlock, BashCodeExecutionOutputBlockParam, BashCodeExecutionResultBlock, BashCodeExecutionResultBlockParam, BashCodeExecutionToolResultBlock, BashCodeExecutionToolResultBlockParam, BashCodeExecutionToolResultError, BashCodeExecutionToolResultErrorCode, BashCodeExecutionToolResultErrorParam, BrowserClickTarget, BrowserCloseTabConfig, BrowserCloseTabInput, BrowserCloseTabToolUseBlock, BrowserCoordinateTarget, BrowserDoubleClickConfig, BrowserDoubleClickInput, BrowserDoubleClickToolUseBlock, BrowserFileUploadConfig, BrowserFileUploadInput, BrowserFileUploadToolUseBlock, BrowserFindConfig, BrowserFindInput, BrowserFindToolUseBlock, BrowserFormInputConfig, BrowserFormInputInput, BrowserFormInputToolUseBlock, BrowserFormInputValue, BrowserGetPageTextConfig, BrowserGetPageTextInput, BrowserGetPageTextToolUseBlock, BrowserHoldKeyConfig, BrowserHoldKeyInput, BrowserHoldKeyToolUseBlock, BrowserHoverConfig, BrowserHoverInput, BrowserHoverToolUseBlock, BrowserJavascriptExecConfig, BrowserJavascriptExecInput, BrowserJavascriptExecToolUseBlock, BrowserKeyConfig, BrowserKeyInput, BrowserKeyToolUseBlock, BrowserLeftClickConfig, BrowserLeftClickDragConfig, BrowserLeftClickDragInput, BrowserLeftClickDragToolUseBlock, BrowserLeftClickInput, BrowserLeftClickToolUseBlock, BrowserLeftMouseDownConfig, BrowserLeftMouseDownInput, BrowserLeftMouseDownToolUseBlock, BrowserLeftMouseUpConfig, BrowserLeftMouseUpInput, BrowserLeftMouseUpToolUseBlock, BrowserListTabsConfig, BrowserListTabsInput, BrowserListTabsToolUseBlock, BrowserMemberInput, BrowserMemberName, BrowserMiddleClickConfig, BrowserMiddleClickInput, BrowserMiddleClickToolUseBlock, BrowserMouseMoveConfig, BrowserMouseMoveInput, BrowserMouseMoveToolUseBlock, BrowserNavigateConfig, BrowserNavigateInput, BrowserNavigateToolUseBlock, BrowserNewTabConfig, BrowserNewTabInput, BrowserNewTabToolUseBlock, BrowserReadConsoleConfig, BrowserReadConsoleInput, BrowserReadConsoleToolUseBlock, BrowserReadNetworkConfig, BrowserReadNetworkInput, BrowserReadNetworkToolUseBlock, BrowserReadPageConfig, BrowserReadPageFilter, BrowserReadPageInput, BrowserReadPageToolUseBlock, BrowserRefTarget, BrowserRightClickConfig, BrowserRightClickInput, BrowserRightClickToolUseBlock, BrowserScreenshotConfig, BrowserScreenshotInput, BrowserScreenshotToolUseBlock, BrowserScrollConfig, BrowserScrollDirection, BrowserScrollInput, BrowserScrollToConfig, BrowserScrollToInput, BrowserScrollToToolUseBlock, BrowserScrollToolUseBlock, BrowserStateBlockParam, BrowserStateChange, BrowserStateChangeDownloadCompleted, BrowserStateChangeDownloadFailed, BrowserStateChangeDownloadStarted, BrowserStateChangeTabOpened, BrowserStateTabEntry, BrowserSwitchTabConfig, BrowserSwitchTabInput, BrowserSwitchTabToolUseBlock, BrowserToolUseBlock, BrowserToolset20260801, BrowserToolsetConfigs, BrowserTripleClickConfig, BrowserTripleClickInput, BrowserTripleClickToolUseBlock, BrowserTypeConfig, BrowserTypeInput, BrowserTypeToolUseBlock, BrowserWaitConfig, BrowserWaitInput, BrowserWaitToolUseBlock, BrowserZoomConfig, BrowserZoomInput, BrowserZoomToolUseBlock, CacheControlEphemeral, CacheCreation, CacheMissMessagesChanged, CacheMissModelChanged, CacheMissPreviousMessageNotFound, CacheMissReason, CacheMissSystemChanged, CacheMissToolsChanged, CacheMissUnavailable, CitationCharLocation, CitationCharLocationParam, CitationContentBlockLocation, CitationContentBlockLocationParam, CitationPageLocation, CitationPageLocationParam, CitationSearchResultLocationParam, CitationWebSearchResultLocationParam, CitationsConfig, CitationsConfigParam, CitationsDelta, CitationsSearchResultLocation, CitationsWebSearchResultLocation, ClientToolUnion, CodeExecutionOutputBlock, CodeExecutionOutputBlockParam, CodeExecutionResultBlock, CodeExecutionResultBlockParam, CodeExecutionTool20250522, CodeExecutionTool20250825, CodeExecutionTool20260120, CodeExecutionTool20260521, CodeExecutionToolResultBlock, CodeExecutionToolResultBlockContent, CodeExecutionToolResultBlockParam, CodeExecutionToolResultBlockParamContent, CodeExecutionToolResultError, CodeExecutionToolResultErrorCode, CodeExecutionToolResultErrorParam, ComputerCursorPositionConfig, ComputerCursorPositionInput, ComputerCursorPositionToolUseBlock, ComputerDoubleClickConfig, ComputerDoubleClickInput, ComputerDoubleClickToolUseBlock, ComputerHoldKeyConfig, ComputerHoldKeyInput, ComputerHoldKeyToolUseBlock, ComputerKeyConfig, ComputerKeyInput, ComputerKeyToolUseBlock, ComputerLeftClickConfig, ComputerLeftClickDragConfig, ComputerLeftClickDragInput, ComputerLeftClickDragToolUseBlock, ComputerLeftClickInput, ComputerLeftClickToolUseBlock, ComputerLeftMouseDownConfig, ComputerLeftMouseDownInput, ComputerLeftMouseDownToolUseBlock, ComputerLeftMouseUpConfig, ComputerLeftMouseUpInput, ComputerLeftMouseUpToolUseBlock, ComputerMemberInput, ComputerMemberName, ComputerMiddleClickConfig, ComputerMiddleClickInput, ComputerMiddleClickToolUseBlock, ComputerMouseMoveConfig, ComputerMouseMoveInput, ComputerMouseMoveToolUseBlock, ComputerRightClickConfig, ComputerRightClickInput, ComputerRightClickToolUseBlock, ComputerScreenshotConfig, ComputerScreenshotInput, ComputerScreenshotToolUseBlock, ComputerScrollConfig, ComputerScrollDirection, ComputerScrollInput, ComputerScrollToolUseBlock, ComputerToolUseBlock, ComputerToolset20260801, ComputerToolsetConfigs, ComputerTripleClickConfig, ComputerTripleClickInput, ComputerTripleClickToolUseBlock, ComputerTypeConfig, ComputerTypeInput, ComputerTypeToolUseBlock, ComputerWaitConfig, ComputerWaitInput, ComputerWaitToolUseBlock, ComputerZoomConfig, ComputerZoomInput, ComputerZoomToolUseBlock, Container, ContainerParams, ContainerSkill, ContainerUploadBlock, ContainerUploadBlockParam, ContentBlock, ContentBlockDeltaEvent, ContentBlockParam, ContentBlockStartEvent, ContentBlockStopEvent, ContentBlockSource, ContentBlockSourceContent, Diagnostics, DiagnosticsParam, DirectCaller, DocumentBlock, DocumentBlockParam, EncryptedCodeExecutionResultBlock, EncryptedCodeExecutionResultBlockParam, FileDocumentSource, FileImageSource, ImageBlockParam, ImageTransformationsParam, InputJSONDelta, JSONOutputFormat, MemoryTool20250818, Message, MessageContentParam, MessageStreamParams, MessageCountTokensParams, MessageCountTokensTool, MessageCreateParams, MessageCreateParamsContainer, MessageCreateParamsNonStreaming, MessageCreateParamsStreaming, MessageDeltaEvent, MessageDeltaUsage, MessageParam, MessageStartEvent, MessageStopEvent, MessageStreamEvent, MessageTokensCount, Messages, Metadata, Model, OutputConfig, OutputTokensDetails, PlainTextSource, RawContentBlockDelta, RawContentBlockDeltaEvent, RawContentBlockStartEvent, RawContentBlockStopEvent, RawMessageDeltaEvent, RawMessageStartEvent, RawMessageStopEvent, RawMessageStreamEvent, RedactedThinkingBlock, RedactedThinkingBlockParam, RefusalStopDetails, ResponseBrowserCloseTabToolUseBlock, ResponseBrowserDoubleClickToolUseBlock, ResponseBrowserFileUploadToolUseBlock, ResponseBrowserFindToolUseBlock, ResponseBrowserFormInputToolUseBlock, ResponseBrowserGetPageTextToolUseBlock, ResponseBrowserHoldKeyToolUseBlock, ResponseBrowserHoverToolUseBlock, ResponseBrowserJavascriptExecToolUseBlock, ResponseBrowserKeyToolUseBlock, ResponseBrowserLeftClickDragToolUseBlock, ResponseBrowserLeftClickToolUseBlock, ResponseBrowserLeftMouseDownToolUseBlock, ResponseBrowserLeftMouseUpToolUseBlock, ResponseBrowserListTabsToolUseBlock, ResponseBrowserMiddleClickToolUseBlock, ResponseBrowserMouseMoveToolUseBlock, ResponseBrowserNavigateToolUseBlock, ResponseBrowserNewTabToolUseBlock, ResponseBrowserReadConsoleToolUseBlock, ResponseBrowserReadNetworkToolUseBlock, ResponseBrowserReadPageToolUseBlock, ResponseBrowserRightClickToolUseBlock, ResponseBrowserScreenshotToolUseBlock, ResponseBrowserScrollToToolUseBlock, ResponseBrowserScrollToolUseBlock, ResponseBrowserSwitchTabToolUseBlock, ResponseBrowserToolUseBlock, ResponseBrowserTripleClickToolUseBlock, ResponseBrowserTypeToolUseBlock, ResponseBrowserWaitToolUseBlock, ResponseBrowserZoomToolUseBlock, ResponseComputerCursorPositionToolUseBlock, ResponseComputerDoubleClickToolUseBlock, ResponseComputerHoldKeyToolUseBlock, ResponseComputerKeyToolUseBlock, ResponseComputerLeftClickDragToolUseBlock, ResponseComputerLeftClickToolUseBlock, ResponseComputerLeftMouseDownToolUseBlock, ResponseComputerLeftMouseUpToolUseBlock, ResponseComputerMiddleClickToolUseBlock, ResponseComputerMouseMoveToolUseBlock, ResponseComputerRightClickToolUseBlock, ResponseComputerScreenshotToolUseBlock, ResponseComputerScrollToolUseBlock, ResponseComputerToolUseBlock, ResponseComputerTripleClickToolUseBlock, ResponseComputerTypeToolUseBlock, ResponseComputerWaitToolUseBlock, ResponseComputerZoomToolUseBlock, ResponseToolUseBlockUnion, SearchResultBlockParam, ServerToolCaller, ServerToolCaller20260120, ServerToolUsage, ServerToolUseBlock, ServerToolUseBlockParam, SignatureDelta, SkillParams, StopReason, SystemMessageParam, TextBlock, TextBlockParam, TextCitation, TextCitationParam, TextDelta, TextEditorCodeExecutionCreateResultBlock, TextEditorCodeExecutionCreateResultBlockParam, TextEditorCodeExecutionStrReplaceResultBlock, TextEditorCodeExecutionStrReplaceResultBlockParam, TextEditorCodeExecutionToolResultBlock, TextEditorCodeExecutionToolResultBlockParam, TextEditorCodeExecutionToolResultError, TextEditorCodeExecutionToolResultErrorCode, TextEditorCodeExecutionToolResultErrorParam, TextEditorCodeExecutionViewResultBlock, TextEditorCodeExecutionViewResultBlockParam, ThinkingBlock, ThinkingBlockParam, ThinkingConfigAdaptive, ThinkingConfigBetweenTools, ThinkingConfigDisabled, ThinkingConfigEnabled, ThinkingConfigParam, ThinkingDelta, Tool, ToolBash20250124, ToolChoice, ToolChoiceAny, ToolChoiceAuto, ToolChoiceNone, ToolChoiceTool, ToolReferenceBlock, ToolReferenceBlockParam, ToolResultBlockParam, ToolSearchToolBm25_20251119, ToolSearchToolRegex20251119, ToolSearchToolResultBlock, ToolSearchToolResultBlockParam, ToolSearchToolResultError, ToolSearchToolResultErrorCode, ToolSearchToolResultErrorParam, ToolSearchToolSearchResultBlock, ToolSearchToolSearchResultBlockParam, ToolTextEditor20250124, ToolTextEditor20250429, ToolTextEditor20250728, ToolUnion, ToolUseBlock, ToolUseBlockParam, ToolUseCaller, ToolsetToolUseBlock, URLImageSource, URLPDFSource, Usage, UserLocation, UserMessageParam, WebFetchBlock, WebFetchBlockParam, WebFetchTool20250910, WebFetchTool20260209, WebFetchTool20260309, WebFetchTool20260318, WebFetchToolResultBlock, WebFetchToolResultBlockParam, WebFetchToolResultErrorBlock, WebFetchToolResultErrorBlockParam, WebFetchToolResultErrorCode, WebFetchURLSourceAll, WebFetchURLSourceExcept, WebFetchURLSourceNone, WebFetchURLSourceOnly, WebFetchURLSourceToolReference, WebFetchURLSources, WebSearchResultBlock, WebSearchResultBlockParam, WebSearchTool20250305, WebSearchTool20260209, WebSearchTool20260318, WebSearchToolRequestError, WebSearchToolResultBlock, WebSearchToolResultBlockContent, WebSearchToolResultBlockParam, WebSearchToolResultBlockParamContent, WebSearchToolResultError, WebSearchToolResultErrorCode } from "./resources/messages/messages.mjs";
import { Organization, OrganizationInfo, OrganizationRole } from "./resources/organization/organization.mjs";
import { DeletedSkill, Skill, SkillCreateParams, SkillDeleteParams, SkillListParams, SkillRetrieveParams, SkillSource, Skills, SkillsPageCursor } from "./resources/skills/skills.mjs";
import { DeletedUserProfile, UserProfile, UserProfileAccessType, UserProfileCreateParams, UserProfileCyberProgram, UserProfileCyberRequirements, UserProfileCyberTier, UserProfileDeleteParams, UserProfileEfsFeature, UserProfileEfsProgram, UserProfileEnforcementAction, UserProfileEnforcementActionBan, UserProfileEnforcementActionNextStep, UserProfileEnforcementActionReason, UserProfileEnforcementActionRestriction, UserProfileEnforcementStatus, UserProfileExternalUserAccountStatus, UserProfileExternalUserDetails, UserProfileExternalUserDetailsParams, UserProfileExternalUserEntityType, UserProfileListOrder, UserProfileListOrderBy, UserProfileListParams, UserProfileProgramStatus, UserProfilePrograms, UserProfileRetrieveParams, UserProfileUpdateParams, UserProfiles, UserProfilesPageCursor } from "./resources/user-profiles/user-profiles.mjs";
import { type Fetch } from "./internal/builtin-types.mjs";
import { HeadersLike, NullableHeaders } from "./internal/headers.mjs";
import { FinalRequestOptions, RequestOptions } from "./internal/request-options.mjs";
import { type LogLevel, type Logger } from "./internal/utils/log.mjs";
export type ApiKeySetter = () => Promise<string>;
export interface ClientOptions {
    /**
     * API key used for authentication.
     *
     * - Accepts either a static string or an async function that resolves to a string.
     * - Sent as `Authorization: Bearer <key>`.
     * - Mutually exclusive with `authToken`, `credentials`, `config`, and `profile`.
     * - Defaults to process.env['ANTHROPIC_API_KEY'], which is not read when one of those options is passed.
     * - When a function is provided, it is invoked before each request so you can rotate
     *   or refresh credentials at runtime.
     * - The function must return a non-empty string; otherwise an AnthropicError is thrown.
     * - If the function throws, the error is wrapped in an AnthropicError with the original
     *   error available as `cause`.
     */
    apiKey?: string | ApiKeySetter | null | undefined;
    /**
     * Defaults to process.env['ANTHROPIC_AUTH_TOKEN'].
     *
     * The environment variable is not used when `apiKey`, `credentials`,
     * `config`, or `profile` is passed, or when `ANTHROPIC_API_KEY` is set, which
     * logs a warning once per process. Mutually exclusive with those options.
     */
    authToken?: string | null | undefined;
    /**
     * An {@link AccessTokenProvider} for OAuth/workload-identity authentication.
     *
     * When set, the provider is wrapped in a {@link TokenCache} and used for
     * Bearer token auth on every request. Mutually exclusive with `apiKey`,
     * `authToken`, `config`, and `profile`.
     *
     * If none of these options is passed (and neither `ANTHROPIC_API_KEY` nor
     * `ANTHROPIC_AUTH_TOKEN` is set), the client resolves credentials on the
     * first request, from the first of these: the profile `ANTHROPIC_PROFILE`
     * names, which is an error if it does not exist; the workload identity
     * federation variables; the active profile on disk, which is the one the
     * `active_config` file names, otherwise `default`.
     */
    credentials?: AccessTokenProvider | null | undefined;
    /**
     * An {@link AnthropicConfig} object to resolve credentials from directly,
     * bypassing config-file and environment-variable lookup.
     *
     * Mutually exclusive with `apiKey`, `authToken`, `credentials`, and
     * `profile`. For `oidc_federation`, the SDK performs the jwt-bearer exchange
     * in-process; for `user_oauth`, `authentication.credentials_path` must point
     * at the credentials file.
     */
    config?: AnthropicConfig | null | undefined;
    /**
     * Name of a profile to load from `<config_dir>/configs/<profile>.json`.
     *
     * Selects a profile as the `ANTHROPIC_PROFILE` environment variable does, but
     * for this client instance only. As an explicit constructor argument it takes
     * precedence over every credential in the environment, so a profile that
     * does not exist is an error. Mutually exclusive with `apiKey`, `authToken`,
     * `credentials`, and `config`.
     */
    profile?: string | null | undefined;
    /**
     * Defaults to process.env['ANTHROPIC_WEBHOOK_SIGNING_KEY'].
     */
    webhookKey?: string | null | undefined;
    /**
     * Override the default base URL for the API, e.g., "https://api.example.com/v2/"
     *
     * Defaults to process.env['ANTHROPIC_BASE_URL'].
     */
    baseURL?: string | null | undefined;
    /**
     * The maximum amount of time (in milliseconds) that the client should wait for a response
     * from the server before timing out a single request.
     *
     * Note that request timeouts are retried by default, so in a worst-case scenario you may wait
     * much longer than this timeout before the promise succeeds or fails.
     *
     * @unit milliseconds
     */
    timeout?: number | undefined;
    /**
     * Additional `RequestInit` options to be passed to `fetch` calls.
     * Properties will be overridden by per-request `fetchOptions`.
     */
    fetchOptions?: MergedRequestInit | undefined;
    /**
     * Specify a custom `fetch` function implementation.
     *
     * If not provided, we expect that `fetch` is defined globally.
     */
    fetch?: Fetch | undefined;
    /**
     * {@link Middleware} functions that wrap every HTTP request made by the
     * client.
     *
     * Middleware runs per HTTP attempt, including retries. It observes the
     * canonical Anthropic-shaped request and response on every backend: on
     * clients for third-party backends (Bedrock, Vertex, Foundry), the
     * backend's URL/body rewriting, request signing, and response
     * normalization happen inside `next`.
     */
    middleware?: ReadonlyArray<Middleware> | undefined;
    /**
     * The maximum number of times that the client will retry a request in case of a
     * temporary failure, like a network error or a 5XX error from the server.
     *
     * @default 2
     */
    maxRetries?: number | undefined;
    /**
     * Default headers to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * header to `null` in request options.
     */
    defaultHeaders?: HeadersLike | undefined;
    /**
     * Default query parameters to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * param to `undefined` in request options.
     */
    defaultQuery?: Record<string, string | undefined> | undefined;
    /**
     * By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     * Only set this option to `true` if you understand the risks and have appropriate mitigations in place.
     */
    dangerouslyAllowBrowser?: boolean | undefined;
    /**
     * OpenTelemetry tracing of this client's API calls. Each API call emits a span when
     * the application has registered a tracer provider with the OpenTelemetry API.
     *
     * `false`, short for `{ traces: false }`, disables the spans.
     * `propagation: false` keeps the spans and sends no trace context with the requests.
     *
     * A client without this option reads its environment variables once, when it is constructed:
     * `ANTHROPIC_OPEN_TELEMETRY` set to `false` disables the spans,
     * `ANTHROPIC_OPEN_TELEMETRY_PROPAGATION` set to `false` turns `propagation` off, and
     * `ANTHROPIC_OPEN_TELEMETRY_TRACES_CONTENT_MODE` and
     * `ANTHROPIC_OPEN_TELEMETRY_TRACES_MAX_CONTENT_BYTES` give `traces.contentMode` and
     * `traces.maxContentBytes`. A client with this option does not read them: a field that the
     * option leaves unset has its default.
     *
     * A `withOptions()` copy without its own `openTelemetry` option keeps this client's settled one.
     * A copy with its own option uses that in place of this client's whole option, so it keeps none
     * of this client's fields. Spread {@link BaseAnthropic.openTelemetry} into the copy's option to
     * keep them.
     */
    openTelemetry?: OpenTelemetryOptions | false | undefined;
    /**
     * Set the log level.
     *
     * Defaults to process.env['ANTHROPIC_LOG'] or 'warn' if it isn't set.
     */
    logLevel?: LogLevel | undefined;
    /**
     * Set the logger.
     *
     * Defaults to globalThis.console.
     */
    logger?: Logger | undefined;
}
/**
 * Base class for Anthropic API clients.
 */
export declare class BaseAnthropic {
    #private;
    apiKey: string | null;
    authToken: string | null;
    webhookKey: string | null;
    /**
     * The active credential provider. Default credential resolution runs once
     * at construction time. If it fails, the error is surfaced on every
     * request and the client must be reconstructed — there is no retry path.
     *
     * Clones returned by {@link withOptions} share the parent's auth state
     * (provider, token cache, pending resolution, and any resolution error)
     * unless the caller passes an explicit `apiKey`, `authToken`,
     * `credentials`, `config`, or `profile` override.
     */
    get credentials(): AccessTokenProvider | null;
    private _authState;
    /**
     * Whether `baseURL` was chosen by the caller (constructor arg or env var)
     * rather than derived. Non-explicit base URLs may be replaced — by a
     * profile-supplied host, or by re-derivation in `withOptions()` clones.
     * Subclasses that derive their own base URL should correct this after
     * `super()`, since the base constructor can't tell a derived value apart.
     */
    protected _baseURLIsExplicit: boolean;
    private _requestAuthFlags;
    baseURL: string;
    maxRetries: number;
    timeout: number;
    logger: Logger;
    logLevel: LogLevel | undefined;
    fetchOptions: MergedRequestInit | undefined;
    middleware: ReadonlyArray<Middleware>;
    private fetch;
    /**
     * The `openTelemetry` option as this client settled it when it was constructed: `propagation` and
     * each field of `traces` from the option, or else its default. A client constructed without the
     * option has what the environment variables said. One constructed with `openTelemetry: false` has
     * `traces.enabled: false` here.
     *
     * The value is frozen. It is a valid `openTelemetry` option, so a copy of this client can change
     * one setting and keep the others:
     *
     * ```ts
     * const { openTelemetry } = client;
     * client.withOptions({
     *   openTelemetry: { ...openTelemetry, traces: { ...openTelemetry.traces, contentMode: 'content' } },
     * });
     * ```
     */
    get openTelemetry(): ResolvedOpenTelemetryOptions;
    /**
     * API Client for interfacing with the Anthropic API.
     *
     * @param {string | null | undefined} [opts.apiKey=process.env['ANTHROPIC_API_KEY'] ?? null]
     * @param {string | null | undefined} [opts.authToken=process.env['ANTHROPIC_AUTH_TOKEN'] ?? null]
     * @param {string | null | undefined} [opts.webhookKey=process.env['ANTHROPIC_WEBHOOK_SIGNING_KEY'] ?? null]
     * @param {string} [opts.baseURL=process.env['ANTHROPIC_BASE_URL'] ?? https://api.anthropic.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL, apiKey, authToken, webhookKey, ...opts }?: ClientOptions);
    /**
     * Whether to lazily resolve auth from the default credential chain when no
     * explicit auth is configured. Called once from the constructor, so
     * overrides must not depend on subclass instance state. Subclasses that
     * bring their own auth scheme return false so unrelated local credentials
     * are never resolved or allowed to supply a base URL.
     */
    protected _shouldResolveDefaultCredentials(): boolean;
    /**
     * Stores a profile/config-supplied base URL on the shared auth state and, if
     * the caller did not pin `baseURL` via constructor option or env, adopts it
     * as this client's outbound API host. Precedence: ctor opt > env > profile >
     * hardcoded default.
     */
    private _applyCredentialBaseURL;
    /**
     * Options bag passed into the credential chain. `baseURL` here is only the
     * fallback host for the token-exchange POST when the config itself omits
     * `base_url`; the chain returns the config's own `base_url` (if any) on
     * {@link CredentialResult.baseURL}, which {@link _applyCredentialBaseURL}
     * then adopts for outbound API requests. The two are deliberately decoupled
     * so this fallback never round-trips into precedence.
     */
    private _credentialResolverOptions;
    /**
     * A `Fetch` for first-party credential token-exchange requests (OIDC
     * federation jwt-bearer grants, user-OAuth refresh grants) that routes
     * through this client's middleware chain, so middleware observes token
     * traffic like any other request. Only client-level middleware applies:
     * a minted token is shared across requests, so attributing the exchange
     * to any one request's per-request middleware would be arbitrary. For the
     * same reason, `ctx.options` is undefined for these requests.
     */
    private _credentialsFetch;
    private _makeTokenCache;
    /**
     * Create a new client instance re-using the same options given to the
     * current client with optional overriding.
     *
     * Passing `apiKey`, `authToken`, `credentials`, `config`, or `profile`
     * replaces the current client's credential, whatever its kind. With none of
     * them passed, the new client keeps it. Either way it keeps
     * `defaultHeaders`, including an `X-Api-Key` or `Authorization` set there.
     */
    withOptions(options: Partial<ClientOptions>): this;
    /**
     * Lazily resolves credentials from config files or environment variables.
     * Called once from the constructor when no explicit auth is provided, or
     * when an explicit `profile` was passed (in which case a missing/unresolved
     * profile is surfaced as an error instead of falling through to "no auth").
     * The returned promise is stored and awaited on the first request.
     */
    private _resolveDefaultCredentials;
    protected defaultQuery(): Record<string, string | undefined> | undefined;
    protected validateHeaders({ values, nulls }: NullableHeaders): void;
    private _authFlags;
    protected authHeaders(opts: FinalRequestOptions): Promise<NullableHeaders | undefined>;
    protected apiKeyAuth(opts: FinalRequestOptions): Promise<NullableHeaders | undefined>;
    protected bearerAuth(opts: FinalRequestOptions): Promise<NullableHeaders | undefined>;
    protected stringifyQuery(query: object | Record<string, unknown>): string;
    protected getUserAgent(): string;
    protected makeStatusError(status: number, error: Object, message: string | undefined, headers: Headers): Errors.APIError;
    buildURL(path: string, query: Record<string, unknown> | null | undefined, defaultBaseURL?: string | undefined): string;
    _calculateNonstreamingTimeout(maxTokens: number): number;
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    protected prepareOptions(options: FinalRequestOptions): Promise<void>;
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     *
     * Runs after all middleware (including {@link backendMiddleware}),
     * immediately before each underlying fetch call, so it sees exactly what
     * goes over the wire, except the trace-context headers of a traced call
     * (`traceparent`, `tracestate`, `baggage`, and any other that the registered
     * propagator writes): the client sets them again after this hook, so that a
     * signature does not cover them. Middleware may replay a request by calling
     * `next()` more than once, so this hook can run multiple times per attempt:
     * overrides must be idempotent and overwrite headers from a previous
     * invocation rather than append to them.
     */
    protected prepareRequest(request: RequestInit, { url, options }: {
        url: string;
        options: FinalRequestOptions;
    }): Promise<void>;
    /**
     * Internal {@link Middleware} composed innermost in the chain — inside both
     * client-level and per-request middleware, immediately around the underlying
     * `fetch`. Subclasses for third-party backends override this to adapt the
     * canonical Anthropic-shaped request to the backend's wire shape (URL/body
     * rewriting, request signing) and to normalize the wire response back to the
     * canonical shape (e.g. AWS EventStream to SSE).
     *
     * Running inside the user's middleware means user middleware always observes
     * canonical Anthropic-shaped traffic, and the adaptation re-runs (e.g.
     * re-signs) on every `next()` invocation, covering whatever the middleware
     * mutated. It does not see the trace-context headers of a traced call: see
     * {@link prepareRequest}.
     *
     * Errors thrown here follow the middleware error policy: they propagate to
     * the caller as-is — no retries, no `APIConnectionError` wrapping — unless
     * retryable (see {@link Middleware}); throw a `RetryableError` to opt into
     * the retry path.
     */
    protected backendMiddleware(): ReadonlyArray<Middleware>;
    get<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    post<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    patch<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    put<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    delete<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    private methodRequest;
    request<Rsp>(options: PromiseOrValue<FinalRequestOptions>, remainingRetries?: number | null): APIPromise<Rsp>;
    /**
     * Makes the request inside the call span that the SDK method started and passed in the options
     * (`__span`). The span ends here when the call fails, and otherwise when the application has
     * read the response body: see `APIPromise`.
     */
    private makeTracedRequest;
    private makeRequest;
    getAPIList<Item, PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>>(path: string, Page: new (...args: any[]) => PageClass, opts?: PromiseOrValue<RequestOptions>): Pagination.PagePromise<PageClass, Item>;
    requestAPIList<Item = unknown, PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>>(Page: new (...args: ConstructorParameters<typeof Pagination.AbstractPage>) => PageClass, options: PromiseOrValue<FinalRequestOptions>): Pagination.PagePromise<PageClass, Item>;
    fetchWithTimeout(url: RequestInfo, init: RequestInit | undefined, ms: number, controller: AbortController, requestOptions?: FinalRequestOptions | undefined, logCtx?: {
        requestLogID: string;
        retryOfRequestLogID?: string | undefined;
    } | undefined): Promise<Response>;
    private shouldRetry;
    private retryRequest;
    private calculateDefaultRetryTimeoutMillis;
    calculateNonstreamingTimeout(maxTokens: number, maxNonstreamingTokens?: number): number;
    buildRequest(inputOptions: FinalRequestOptions, { retryCount }?: {
        retryCount?: number;
    }): Promise<{
        req: FinalizedRequestInit;
        url: string;
        timeout: number;
    }>;
    private buildHeaders;
    private _makeAbort;
    private buildBody;
    /**
     * Whether `body` is sent as a stream, which can be read only once:
     * a `ReadableStream`, an async iterable or an iterator.
     */
    private isStreamBody;
    static Anthropic: typeof BaseAnthropic;
    static DEFAULT_TIMEOUT: number;
    static AnthropicError: typeof Errors.AnthropicError;
    static APIError: typeof Errors.APIError;
    static APIConnectionError: typeof Errors.APIConnectionError;
    static APIConnectionTimeoutError: typeof Errors.APIConnectionTimeoutError;
    static APIUserAbortError: typeof Errors.APIUserAbortError;
    static NotFoundError: typeof Errors.NotFoundError;
    static ConflictError: typeof Errors.ConflictError;
    static RateLimitError: typeof Errors.RateLimitError;
    static BadRequestError: typeof Errors.BadRequestError;
    static AuthenticationError: typeof Errors.AuthenticationError;
    static InternalServerError: typeof Errors.InternalServerError;
    static PermissionDeniedError: typeof Errors.PermissionDeniedError;
    static UnprocessableEntityError: typeof Errors.UnprocessableEntityError;
    static toFile: typeof Uploads.toFile;
}
/**
 * API Client for interfacing with the Anthropic API.
 */
export declare class Anthropic extends BaseAnthropic {
    messages: API.Messages;
    models: API.Models;
    files: API.Files;
    skills: API.Skills;
    userProfiles: API.UserProfiles;
    organization: API.Organization;
    beta: API.Beta;
}
export declare namespace Anthropic {
    export type RequestOptions = Opts.RequestOptions;
    export type FinalRequestOptions = Opts.FinalRequestOptions;
    export type { ApiKeySetter };
    export { type Page as Page, type PageParams as PageParams, type PageResponse as PageResponse };
    export { type TokenPage as TokenPage, type TokenPageParams as TokenPageParams, type TokenPageResponse as TokenPageResponse, };
    export { type PageCursor as PageCursor, type PageCursorParams as PageCursorParams, type PageCursorResponse as PageCursorResponse, };
    export { type BidirectionalPageCursor as BidirectionalPageCursor, type BidirectionalPageCursorParams as BidirectionalPageCursorParams, type BidirectionalPageCursorResponse as BidirectionalPageCursorResponse, };
    export { type ReportPageCursor as ReportPageCursor, type ReportPageCursorParams as ReportPageCursorParams, type ReportPageCursorResponse as ReportPageCursorResponse, };
    export { Messages as Messages, type AssistantMessageParam as AssistantMessageParam, type Base64ImageSource as Base64ImageSource, type Base64PDFSource as Base64PDFSource, type BashCodeExecutionOutputBlock as BashCodeExecutionOutputBlock, type BashCodeExecutionOutputBlockParam as BashCodeExecutionOutputBlockParam, type BashCodeExecutionResultBlock as BashCodeExecutionResultBlock, type BashCodeExecutionResultBlockParam as BashCodeExecutionResultBlockParam, type BashCodeExecutionToolResultBlock as BashCodeExecutionToolResultBlock, type BashCodeExecutionToolResultBlockParam as BashCodeExecutionToolResultBlockParam, type BashCodeExecutionToolResultError as BashCodeExecutionToolResultError, type BashCodeExecutionToolResultErrorCode as BashCodeExecutionToolResultErrorCode, type BashCodeExecutionToolResultErrorParam as BashCodeExecutionToolResultErrorParam, type BrowserClickTarget as BrowserClickTarget, type BrowserCloseTabConfig as BrowserCloseTabConfig, type BrowserCloseTabInput as BrowserCloseTabInput, type BrowserCloseTabToolUseBlock as BrowserCloseTabToolUseBlock, type BrowserCoordinateTarget as BrowserCoordinateTarget, type BrowserDoubleClickConfig as BrowserDoubleClickConfig, type BrowserDoubleClickInput as BrowserDoubleClickInput, type BrowserDoubleClickToolUseBlock as BrowserDoubleClickToolUseBlock, type BrowserFileUploadConfig as BrowserFileUploadConfig, type BrowserFileUploadInput as BrowserFileUploadInput, type BrowserFileUploadToolUseBlock as BrowserFileUploadToolUseBlock, type BrowserFindConfig as BrowserFindConfig, type BrowserFindInput as BrowserFindInput, type BrowserFindToolUseBlock as BrowserFindToolUseBlock, type BrowserFormInputConfig as BrowserFormInputConfig, type BrowserFormInputInput as BrowserFormInputInput, type BrowserFormInputToolUseBlock as BrowserFormInputToolUseBlock, type BrowserFormInputValue as BrowserFormInputValue, type BrowserGetPageTextConfig as BrowserGetPageTextConfig, type BrowserGetPageTextInput as BrowserGetPageTextInput, type BrowserGetPageTextToolUseBlock as BrowserGetPageTextToolUseBlock, type BrowserHoldKeyConfig as BrowserHoldKeyConfig, type BrowserHoldKeyInput as BrowserHoldKeyInput, type BrowserHoldKeyToolUseBlock as BrowserHoldKeyToolUseBlock, type BrowserHoverConfig as BrowserHoverConfig, type BrowserHoverInput as BrowserHoverInput, type BrowserHoverToolUseBlock as BrowserHoverToolUseBlock, type BrowserJavascriptExecConfig as BrowserJavascriptExecConfig, type BrowserJavascriptExecInput as BrowserJavascriptExecInput, type BrowserJavascriptExecToolUseBlock as BrowserJavascriptExecToolUseBlock, type BrowserKeyConfig as BrowserKeyConfig, type BrowserKeyInput as BrowserKeyInput, type BrowserKeyToolUseBlock as BrowserKeyToolUseBlock, type BrowserLeftClickConfig as BrowserLeftClickConfig, type BrowserLeftClickDragConfig as BrowserLeftClickDragConfig, type BrowserLeftClickDragInput as BrowserLeftClickDragInput, type BrowserLeftClickDragToolUseBlock as BrowserLeftClickDragToolUseBlock, type BrowserLeftClickInput as BrowserLeftClickInput, type BrowserLeftClickToolUseBlock as BrowserLeftClickToolUseBlock, type BrowserLeftMouseDownConfig as BrowserLeftMouseDownConfig, type BrowserLeftMouseDownInput as BrowserLeftMouseDownInput, type BrowserLeftMouseDownToolUseBlock as BrowserLeftMouseDownToolUseBlock, type BrowserLeftMouseUpConfig as BrowserLeftMouseUpConfig, type BrowserLeftMouseUpInput as BrowserLeftMouseUpInput, type BrowserLeftMouseUpToolUseBlock as BrowserLeftMouseUpToolUseBlock, type BrowserListTabsConfig as BrowserListTabsConfig, type BrowserListTabsInput as BrowserListTabsInput, type BrowserListTabsToolUseBlock as BrowserListTabsToolUseBlock, type BrowserMemberInput as BrowserMemberInput, type BrowserMemberName as BrowserMemberName, type BrowserMiddleClickConfig as BrowserMiddleClickConfig, type BrowserMiddleClickInput as BrowserMiddleClickInput, type BrowserMiddleClickToolUseBlock as BrowserMiddleClickToolUseBlock, type BrowserMouseMoveConfig as BrowserMouseMoveConfig, type BrowserMouseMoveInput as BrowserMouseMoveInput, type BrowserMouseMoveToolUseBlock as BrowserMouseMoveToolUseBlock, type BrowserNavigateConfig as BrowserNavigateConfig, type BrowserNavigateInput as BrowserNavigateInput, type BrowserNavigateToolUseBlock as BrowserNavigateToolUseBlock, type BrowserNewTabConfig as BrowserNewTabConfig, type BrowserNewTabInput as BrowserNewTabInput, type BrowserNewTabToolUseBlock as BrowserNewTabToolUseBlock, type BrowserReadConsoleConfig as BrowserReadConsoleConfig, type BrowserReadConsoleInput as BrowserReadConsoleInput, type BrowserReadConsoleToolUseBlock as BrowserReadConsoleToolUseBlock, type BrowserReadNetworkConfig as BrowserReadNetworkConfig, type BrowserReadNetworkInput as BrowserReadNetworkInput, type BrowserReadNetworkToolUseBlock as BrowserReadNetworkToolUseBlock, type BrowserReadPageConfig as BrowserReadPageConfig, type BrowserReadPageFilter as BrowserReadPageFilter, type BrowserReadPageInput as BrowserReadPageInput, type BrowserReadPageToolUseBlock as BrowserReadPageToolUseBlock, type BrowserRefTarget as BrowserRefTarget, type BrowserRightClickConfig as BrowserRightClickConfig, type BrowserRightClickInput as BrowserRightClickInput, type BrowserRightClickToolUseBlock as BrowserRightClickToolUseBlock, type BrowserScreenshotConfig as BrowserScreenshotConfig, type BrowserScreenshotInput as BrowserScreenshotInput, type BrowserScreenshotToolUseBlock as BrowserScreenshotToolUseBlock, type BrowserScrollConfig as BrowserScrollConfig, type BrowserScrollDirection as BrowserScrollDirection, type BrowserScrollInput as BrowserScrollInput, type BrowserScrollToConfig as BrowserScrollToConfig, type BrowserScrollToInput as BrowserScrollToInput, type BrowserScrollToToolUseBlock as BrowserScrollToToolUseBlock, type BrowserScrollToolUseBlock as BrowserScrollToolUseBlock, type BrowserStateBlockParam as BrowserStateBlockParam, type BrowserStateChange as BrowserStateChange, type BrowserStateChangeDownloadCompleted as BrowserStateChangeDownloadCompleted, type BrowserStateChangeDownloadFailed as BrowserStateChangeDownloadFailed, type BrowserStateChangeDownloadStarted as BrowserStateChangeDownloadStarted, type BrowserStateChangeTabOpened as BrowserStateChangeTabOpened, type BrowserStateTabEntry as BrowserStateTabEntry, type BrowserSwitchTabConfig as BrowserSwitchTabConfig, type BrowserSwitchTabInput as BrowserSwitchTabInput, type BrowserSwitchTabToolUseBlock as BrowserSwitchTabToolUseBlock, type BrowserToolUseBlock as BrowserToolUseBlock, type BrowserToolset20260801 as BrowserToolset20260801, type BrowserToolsetConfigs as BrowserToolsetConfigs, type BrowserTripleClickConfig as BrowserTripleClickConfig, type BrowserTripleClickInput as BrowserTripleClickInput, type BrowserTripleClickToolUseBlock as BrowserTripleClickToolUseBlock, type BrowserTypeConfig as BrowserTypeConfig, type BrowserTypeInput as BrowserTypeInput, type BrowserTypeToolUseBlock as BrowserTypeToolUseBlock, type BrowserWaitConfig as BrowserWaitConfig, type BrowserWaitInput as BrowserWaitInput, type BrowserWaitToolUseBlock as BrowserWaitToolUseBlock, type BrowserZoomConfig as BrowserZoomConfig, type BrowserZoomInput as BrowserZoomInput, type BrowserZoomToolUseBlock as BrowserZoomToolUseBlock, type CacheControlEphemeral as CacheControlEphemeral, type CacheCreation as CacheCreation, type CacheMissMessagesChanged as CacheMissMessagesChanged, type CacheMissModelChanged as CacheMissModelChanged, type CacheMissPreviousMessageNotFound as CacheMissPreviousMessageNotFound, type CacheMissReason as CacheMissReason, type CacheMissSystemChanged as CacheMissSystemChanged, type CacheMissToolsChanged as CacheMissToolsChanged, type CacheMissUnavailable as CacheMissUnavailable, type CitationCharLocation as CitationCharLocation, type CitationCharLocationParam as CitationCharLocationParam, type CitationContentBlockLocation as CitationContentBlockLocation, type CitationContentBlockLocationParam as CitationContentBlockLocationParam, type CitationPageLocation as CitationPageLocation, type CitationPageLocationParam as CitationPageLocationParam, type CitationSearchResultLocationParam as CitationSearchResultLocationParam, type CitationWebSearchResultLocationParam as CitationWebSearchResultLocationParam, type CitationsConfig as CitationsConfig, type CitationsConfigParam as CitationsConfigParam, type CitationsDelta as CitationsDelta, type CitationsSearchResultLocation as CitationsSearchResultLocation, type CitationsWebSearchResultLocation as CitationsWebSearchResultLocation, type ClientToolUnion as ClientToolUnion, type CodeExecutionOutputBlock as CodeExecutionOutputBlock, type CodeExecutionOutputBlockParam as CodeExecutionOutputBlockParam, type CodeExecutionResultBlock as CodeExecutionResultBlock, type CodeExecutionResultBlockParam as CodeExecutionResultBlockParam, type CodeExecutionTool20250522 as CodeExecutionTool20250522, type CodeExecutionTool20250825 as CodeExecutionTool20250825, type CodeExecutionTool20260120 as CodeExecutionTool20260120, type CodeExecutionTool20260521 as CodeExecutionTool20260521, type CodeExecutionToolResultBlock as CodeExecutionToolResultBlock, type CodeExecutionToolResultBlockContent as CodeExecutionToolResultBlockContent, type CodeExecutionToolResultBlockParam as CodeExecutionToolResultBlockParam, type CodeExecutionToolResultBlockParamContent as CodeExecutionToolResultBlockParamContent, type CodeExecutionToolResultError as CodeExecutionToolResultError, type CodeExecutionToolResultErrorCode as CodeExecutionToolResultErrorCode, type CodeExecutionToolResultErrorParam as CodeExecutionToolResultErrorParam, type ComputerCursorPositionConfig as ComputerCursorPositionConfig, type ComputerCursorPositionInput as ComputerCursorPositionInput, type ComputerCursorPositionToolUseBlock as ComputerCursorPositionToolUseBlock, type ComputerDoubleClickConfig as ComputerDoubleClickConfig, type ComputerDoubleClickInput as ComputerDoubleClickInput, type ComputerDoubleClickToolUseBlock as ComputerDoubleClickToolUseBlock, type ComputerHoldKeyConfig as ComputerHoldKeyConfig, type ComputerHoldKeyInput as ComputerHoldKeyInput, type ComputerHoldKeyToolUseBlock as ComputerHoldKeyToolUseBlock, type ComputerKeyConfig as ComputerKeyConfig, type ComputerKeyInput as ComputerKeyInput, type ComputerKeyToolUseBlock as ComputerKeyToolUseBlock, type ComputerLeftClickConfig as ComputerLeftClickConfig, type ComputerLeftClickDragConfig as ComputerLeftClickDragConfig, type ComputerLeftClickDragInput as ComputerLeftClickDragInput, type ComputerLeftClickDragToolUseBlock as ComputerLeftClickDragToolUseBlock, type ComputerLeftClickInput as ComputerLeftClickInput, type ComputerLeftClickToolUseBlock as ComputerLeftClickToolUseBlock, type ComputerLeftMouseDownConfig as ComputerLeftMouseDownConfig, type ComputerLeftMouseDownInput as ComputerLeftMouseDownInput, type ComputerLeftMouseDownToolUseBlock as ComputerLeftMouseDownToolUseBlock, type ComputerLeftMouseUpConfig as ComputerLeftMouseUpConfig, type ComputerLeftMouseUpInput as ComputerLeftMouseUpInput, type ComputerLeftMouseUpToolUseBlock as ComputerLeftMouseUpToolUseBlock, type ComputerMemberInput as ComputerMemberInput, type ComputerMemberName as ComputerMemberName, type ComputerMiddleClickConfig as ComputerMiddleClickConfig, type ComputerMiddleClickInput as ComputerMiddleClickInput, type ComputerMiddleClickToolUseBlock as ComputerMiddleClickToolUseBlock, type ComputerMouseMoveConfig as ComputerMouseMoveConfig, type ComputerMouseMoveInput as ComputerMouseMoveInput, type ComputerMouseMoveToolUseBlock as ComputerMouseMoveToolUseBlock, type ComputerRightClickConfig as ComputerRightClickConfig, type ComputerRightClickInput as ComputerRightClickInput, type ComputerRightClickToolUseBlock as ComputerRightClickToolUseBlock, type ComputerScreenshotConfig as ComputerScreenshotConfig, type ComputerScreenshotInput as ComputerScreenshotInput, type ComputerScreenshotToolUseBlock as ComputerScreenshotToolUseBlock, type ComputerScrollConfig as ComputerScrollConfig, type ComputerScrollDirection as ComputerScrollDirection, type ComputerScrollInput as ComputerScrollInput, type ComputerScrollToolUseBlock as ComputerScrollToolUseBlock, type ComputerToolUseBlock as ComputerToolUseBlock, type ComputerToolset20260801 as ComputerToolset20260801, type ComputerToolsetConfigs as ComputerToolsetConfigs, type ComputerTripleClickConfig as ComputerTripleClickConfig, type ComputerTripleClickInput as ComputerTripleClickInput, type ComputerTripleClickToolUseBlock as ComputerTripleClickToolUseBlock, type ComputerTypeConfig as ComputerTypeConfig, type ComputerTypeInput as ComputerTypeInput, type ComputerTypeToolUseBlock as ComputerTypeToolUseBlock, type ComputerWaitConfig as ComputerWaitConfig, type ComputerWaitInput as ComputerWaitInput, type ComputerWaitToolUseBlock as ComputerWaitToolUseBlock, type ComputerZoomConfig as ComputerZoomConfig, type ComputerZoomInput as ComputerZoomInput, type ComputerZoomToolUseBlock as ComputerZoomToolUseBlock, type Container as Container, type ContainerParams as ContainerParams, type ContainerSkill as ContainerSkill, type ContainerUploadBlock as ContainerUploadBlock, type ContainerUploadBlockParam as ContainerUploadBlockParam, type ContentBlock as ContentBlock, type ContentBlockDeltaEvent as ContentBlockDeltaEvent, type ContentBlockParam as ContentBlockParam, type ContentBlockStartEvent as ContentBlockStartEvent, type ContentBlockStopEvent as ContentBlockStopEvent, type ContentBlockSource as ContentBlockSource, type ContentBlockSourceContent as ContentBlockSourceContent, type Diagnostics as Diagnostics, type DiagnosticsParam as DiagnosticsParam, type DirectCaller as DirectCaller, type DocumentBlock as DocumentBlock, type DocumentBlockParam as DocumentBlockParam, type EncryptedCodeExecutionResultBlock as EncryptedCodeExecutionResultBlock, type EncryptedCodeExecutionResultBlockParam as EncryptedCodeExecutionResultBlockParam, type FileDocumentSource as FileDocumentSource, type FileImageSource as FileImageSource, type ImageBlockParam as ImageBlockParam, type ImageTransformationsParam as ImageTransformationsParam, type InputJSONDelta as InputJSONDelta, type JSONOutputFormat as JSONOutputFormat, type MemoryTool20250818 as MemoryTool20250818, type Message as Message, type MessageContentParam as MessageContentParam, type MessageCountTokensTool as MessageCountTokensTool, type MessageCreateParamsContainer as MessageCreateParamsContainer, type MessageDeltaEvent as MessageDeltaEvent, type MessageDeltaUsage as MessageDeltaUsage, type MessageParam as MessageParam, type MessageStartEvent as MessageStartEvent, type MessageStopEvent as MessageStopEvent, type MessageStreamEvent as MessageStreamEvent, type MessageTokensCount as MessageTokensCount, type Metadata as Metadata, type Model as Model, type OutputConfig as OutputConfig, type OutputTokensDetails as OutputTokensDetails, type PlainTextSource as PlainTextSource, type RawContentBlockDelta as RawContentBlockDelta, type RawContentBlockDeltaEvent as RawContentBlockDeltaEvent, type RawContentBlockStartEvent as RawContentBlockStartEvent, type RawContentBlockStopEvent as RawContentBlockStopEvent, type RawMessageDeltaEvent as RawMessageDeltaEvent, type RawMessageStartEvent as RawMessageStartEvent, type RawMessageStopEvent as RawMessageStopEvent, type RawMessageStreamEvent as RawMessageStreamEvent, type RedactedThinkingBlock as RedactedThinkingBlock, type RedactedThinkingBlockParam as RedactedThinkingBlockParam, type RefusalStopDetails as RefusalStopDetails, type SearchResultBlockParam as SearchResultBlockParam, type ServerToolCaller as ServerToolCaller, type ServerToolCaller20260120 as ServerToolCaller20260120, type ServerToolUsage as ServerToolUsage, type ServerToolUseBlock as ServerToolUseBlock, type ServerToolUseBlockParam as ServerToolUseBlockParam, type SignatureDelta as SignatureDelta, type SkillParams as SkillParams, type StopReason as StopReason, type SystemMessageParam as SystemMessageParam, type TextBlock as TextBlock, type TextBlockParam as TextBlockParam, type TextCitation as TextCitation, type TextCitationParam as TextCitationParam, type TextDelta as TextDelta, type TextEditorCodeExecutionCreateResultBlock as TextEditorCodeExecutionCreateResultBlock, type TextEditorCodeExecutionCreateResultBlockParam as TextEditorCodeExecutionCreateResultBlockParam, type TextEditorCodeExecutionStrReplaceResultBlock as TextEditorCodeExecutionStrReplaceResultBlock, type TextEditorCodeExecutionStrReplaceResultBlockParam as TextEditorCodeExecutionStrReplaceResultBlockParam, type TextEditorCodeExecutionToolResultBlock as TextEditorCodeExecutionToolResultBlock, type TextEditorCodeExecutionToolResultBlockParam as TextEditorCodeExecutionToolResultBlockParam, type TextEditorCodeExecutionToolResultError as TextEditorCodeExecutionToolResultError, type TextEditorCodeExecutionToolResultErrorCode as TextEditorCodeExecutionToolResultErrorCode, type TextEditorCodeExecutionToolResultErrorParam as TextEditorCodeExecutionToolResultErrorParam, type TextEditorCodeExecutionViewResultBlock as TextEditorCodeExecutionViewResultBlock, type TextEditorCodeExecutionViewResultBlockParam as TextEditorCodeExecutionViewResultBlockParam, type ThinkingBlock as ThinkingBlock, type ThinkingBlockParam as ThinkingBlockParam, type ThinkingConfigAdaptive as ThinkingConfigAdaptive, type ThinkingConfigBetweenTools as ThinkingConfigBetweenTools, type ThinkingConfigDisabled as ThinkingConfigDisabled, type ThinkingConfigEnabled as ThinkingConfigEnabled, type ThinkingConfigParam as ThinkingConfigParam, type ThinkingDelta as ThinkingDelta, type Tool as Tool, type ToolBash20250124 as ToolBash20250124, type ToolChoice as ToolChoice, type ToolChoiceAny as ToolChoiceAny, type ToolChoiceAuto as ToolChoiceAuto, type ToolChoiceNone as ToolChoiceNone, type ToolChoiceTool as ToolChoiceTool, type ToolReferenceBlock as ToolReferenceBlock, type ToolReferenceBlockParam as ToolReferenceBlockParam, type ToolResultBlockParam as ToolResultBlockParam, type ToolSearchToolBm25_20251119 as ToolSearchToolBm25_20251119, type ToolSearchToolRegex20251119 as ToolSearchToolRegex20251119, type ToolSearchToolResultBlock as ToolSearchToolResultBlock, type ToolSearchToolResultBlockParam as ToolSearchToolResultBlockParam, type ToolSearchToolResultError as ToolSearchToolResultError, type ToolSearchToolResultErrorCode as ToolSearchToolResultErrorCode, type ToolSearchToolResultErrorParam as ToolSearchToolResultErrorParam, type ToolSearchToolSearchResultBlock as ToolSearchToolSearchResultBlock, type ToolSearchToolSearchResultBlockParam as ToolSearchToolSearchResultBlockParam, type ToolTextEditor20250124 as ToolTextEditor20250124, type ToolTextEditor20250429 as ToolTextEditor20250429, type ToolTextEditor20250728 as ToolTextEditor20250728, type ToolUnion as ToolUnion, type ToolUseBlock as ToolUseBlock, type ToolUseBlockParam as ToolUseBlockParam, type ToolUseCaller as ToolUseCaller, type ToolsetToolUseBlock as ToolsetToolUseBlock, type URLImageSource as URLImageSource, type URLPDFSource as URLPDFSource, type Usage as Usage, type UserLocation as UserLocation, type UserMessageParam as UserMessageParam, type WebFetchBlock as WebFetchBlock, type WebFetchBlockParam as WebFetchBlockParam, type WebFetchTool20250910 as WebFetchTool20250910, type WebFetchTool20260209 as WebFetchTool20260209, type WebFetchTool20260309 as WebFetchTool20260309, type WebFetchTool20260318 as WebFetchTool20260318, type WebFetchToolResultBlock as WebFetchToolResultBlock, type WebFetchToolResultBlockParam as WebFetchToolResultBlockParam, type WebFetchToolResultErrorBlock as WebFetchToolResultErrorBlock, type WebFetchToolResultErrorBlockParam as WebFetchToolResultErrorBlockParam, type WebFetchToolResultErrorCode as WebFetchToolResultErrorCode, type WebFetchURLSourceAll as WebFetchURLSourceAll, type WebFetchURLSourceExcept as WebFetchURLSourceExcept, type WebFetchURLSourceNone as WebFetchURLSourceNone, type WebFetchURLSourceOnly as WebFetchURLSourceOnly, type WebFetchURLSourceToolReference as WebFetchURLSourceToolReference, type WebFetchURLSources as WebFetchURLSources, type WebSearchResultBlock as WebSearchResultBlock, type WebSearchResultBlockParam as WebSearchResultBlockParam, type WebSearchTool20250305 as WebSearchTool20250305, type WebSearchTool20260209 as WebSearchTool20260209, type WebSearchTool20260318 as WebSearchTool20260318, type WebSearchToolRequestError as WebSearchToolRequestError, type WebSearchToolResultBlock as WebSearchToolResultBlock, type WebSearchToolResultBlockContent as WebSearchToolResultBlockContent, type WebSearchToolResultBlockParam as WebSearchToolResultBlockParam, type WebSearchToolResultBlockParamContent as WebSearchToolResultBlockParamContent, type WebSearchToolResultError as WebSearchToolResultError, type WebSearchToolResultErrorCode as WebSearchToolResultErrorCode, type ResponseToolUseBlockUnion as ResponseToolUseBlockUnion, type ResponseBrowserToolUseBlock as ResponseBrowserToolUseBlock, type ResponseBrowserCloseTabToolUseBlock as ResponseBrowserCloseTabToolUseBlock, type ResponseBrowserDoubleClickToolUseBlock as ResponseBrowserDoubleClickToolUseBlock, type ResponseBrowserFileUploadToolUseBlock as ResponseBrowserFileUploadToolUseBlock, type ResponseBrowserFindToolUseBlock as ResponseBrowserFindToolUseBlock, type ResponseBrowserFormInputToolUseBlock as ResponseBrowserFormInputToolUseBlock, type ResponseBrowserGetPageTextToolUseBlock as ResponseBrowserGetPageTextToolUseBlock, type ResponseBrowserHoldKeyToolUseBlock as ResponseBrowserHoldKeyToolUseBlock, type ResponseBrowserHoverToolUseBlock as ResponseBrowserHoverToolUseBlock, type ResponseBrowserJavascriptExecToolUseBlock as ResponseBrowserJavascriptExecToolUseBlock, type ResponseBrowserKeyToolUseBlock as ResponseBrowserKeyToolUseBlock, type ResponseBrowserLeftClickDragToolUseBlock as ResponseBrowserLeftClickDragToolUseBlock, type ResponseBrowserLeftClickToolUseBlock as ResponseBrowserLeftClickToolUseBlock, type ResponseBrowserLeftMouseDownToolUseBlock as ResponseBrowserLeftMouseDownToolUseBlock, type ResponseBrowserLeftMouseUpToolUseBlock as ResponseBrowserLeftMouseUpToolUseBlock, type ResponseBrowserListTabsToolUseBlock as ResponseBrowserListTabsToolUseBlock, type ResponseBrowserMiddleClickToolUseBlock as ResponseBrowserMiddleClickToolUseBlock, type ResponseBrowserMouseMoveToolUseBlock as ResponseBrowserMouseMoveToolUseBlock, type ResponseBrowserNavigateToolUseBlock as ResponseBrowserNavigateToolUseBlock, type ResponseBrowserNewTabToolUseBlock as ResponseBrowserNewTabToolUseBlock, type ResponseBrowserReadConsoleToolUseBlock as ResponseBrowserReadConsoleToolUseBlock, type ResponseBrowserReadNetworkToolUseBlock as ResponseBrowserReadNetworkToolUseBlock, type ResponseBrowserReadPageToolUseBlock as ResponseBrowserReadPageToolUseBlock, type ResponseBrowserRightClickToolUseBlock as ResponseBrowserRightClickToolUseBlock, type ResponseBrowserScreenshotToolUseBlock as ResponseBrowserScreenshotToolUseBlock, type ResponseBrowserScrollToToolUseBlock as ResponseBrowserScrollToToolUseBlock, type ResponseBrowserScrollToolUseBlock as ResponseBrowserScrollToolUseBlock, type ResponseBrowserSwitchTabToolUseBlock as ResponseBrowserSwitchTabToolUseBlock, type ResponseBrowserTripleClickToolUseBlock as ResponseBrowserTripleClickToolUseBlock, type ResponseBrowserTypeToolUseBlock as ResponseBrowserTypeToolUseBlock, type ResponseBrowserWaitToolUseBlock as ResponseBrowserWaitToolUseBlock, type ResponseBrowserZoomToolUseBlock as ResponseBrowserZoomToolUseBlock, type ResponseComputerToolUseBlock as ResponseComputerToolUseBlock, type ResponseComputerCursorPositionToolUseBlock as ResponseComputerCursorPositionToolUseBlock, type ResponseComputerDoubleClickToolUseBlock as ResponseComputerDoubleClickToolUseBlock, type ResponseComputerHoldKeyToolUseBlock as ResponseComputerHoldKeyToolUseBlock, type ResponseComputerKeyToolUseBlock as ResponseComputerKeyToolUseBlock, type ResponseComputerLeftClickDragToolUseBlock as ResponseComputerLeftClickDragToolUseBlock, type ResponseComputerLeftClickToolUseBlock as ResponseComputerLeftClickToolUseBlock, type ResponseComputerLeftMouseDownToolUseBlock as ResponseComputerLeftMouseDownToolUseBlock, type ResponseComputerLeftMouseUpToolUseBlock as ResponseComputerLeftMouseUpToolUseBlock, type ResponseComputerMiddleClickToolUseBlock as ResponseComputerMiddleClickToolUseBlock, type ResponseComputerMouseMoveToolUseBlock as ResponseComputerMouseMoveToolUseBlock, type ResponseComputerRightClickToolUseBlock as ResponseComputerRightClickToolUseBlock, type ResponseComputerScreenshotToolUseBlock as ResponseComputerScreenshotToolUseBlock, type ResponseComputerScrollToolUseBlock as ResponseComputerScrollToolUseBlock, type ResponseComputerTripleClickToolUseBlock as ResponseComputerTripleClickToolUseBlock, type ResponseComputerTypeToolUseBlock as ResponseComputerTypeToolUseBlock, type ResponseComputerWaitToolUseBlock as ResponseComputerWaitToolUseBlock, type ResponseComputerZoomToolUseBlock as ResponseComputerZoomToolUseBlock, type MessageCreateParams as MessageCreateParams, type MessageCreateParamsNonStreaming as MessageCreateParamsNonStreaming, type MessageCreateParamsStreaming as MessageCreateParamsStreaming, type MessageStreamParams as MessageStreamParams, type MessageCountTokensParams as MessageCountTokensParams, };
    export { Models as Models, type CapabilitySupport as CapabilitySupport, type ContextManagementCapability as ContextManagementCapability, type EffortCapability as EffortCapability, type ModelCapabilities as ModelCapabilities, type ModelInfo as ModelInfo, type ModelLine as ModelLine, type ServerToolsCapability as ServerToolsCapability, type ThinkingCapability as ThinkingCapability, type ThinkingTypes as ThinkingTypes, type ModelInfosPage as ModelInfosPage, type ModelRetrieveParams as ModelRetrieveParams, type ModelListParams as ModelListParams, };
    export { Files as Files, type DeletedFile as DeletedFile, type FileMetadata as FileMetadata, type FileMetadataPageCursor as FileMetadataPageCursor, type FileListParams as FileListParams, type FileDeleteParams as FileDeleteParams, type FileDownloadParams as FileDownloadParams, type FileRetrieveMetadataParams as FileRetrieveMetadataParams, type FileUploadParams as FileUploadParams, };
    export { Skills as Skills, type DeletedSkill as DeletedSkill, type Skill as Skill, type SkillSource as SkillSource, type SkillsPageCursor as SkillsPageCursor, type SkillCreateParams as SkillCreateParams, type SkillRetrieveParams as SkillRetrieveParams, type SkillListParams as SkillListParams, type SkillDeleteParams as SkillDeleteParams, };
    export { UserProfiles as UserProfiles, type DeletedUserProfile as DeletedUserProfile, type UserProfile as UserProfile, type UserProfileAccessType as UserProfileAccessType, type UserProfileCyberProgram as UserProfileCyberProgram, type UserProfileCyberRequirements as UserProfileCyberRequirements, type UserProfileCyberTier as UserProfileCyberTier, type UserProfileEfsFeature as UserProfileEfsFeature, type UserProfileEfsProgram as UserProfileEfsProgram, type UserProfileEnforcementAction as UserProfileEnforcementAction, type UserProfileEnforcementActionBan as UserProfileEnforcementActionBan, type UserProfileEnforcementActionNextStep as UserProfileEnforcementActionNextStep, type UserProfileEnforcementActionReason as UserProfileEnforcementActionReason, type UserProfileEnforcementActionRestriction as UserProfileEnforcementActionRestriction, type UserProfileEnforcementStatus as UserProfileEnforcementStatus, type UserProfileExternalUserAccountStatus as UserProfileExternalUserAccountStatus, type UserProfileExternalUserDetails as UserProfileExternalUserDetails, type UserProfileExternalUserDetailsParams as UserProfileExternalUserDetailsParams, type UserProfileExternalUserEntityType as UserProfileExternalUserEntityType, type UserProfileListOrder as UserProfileListOrder, type UserProfileListOrderBy as UserProfileListOrderBy, type UserProfileProgramStatus as UserProfileProgramStatus, type UserProfilePrograms as UserProfilePrograms, type UserProfilesPageCursor as UserProfilesPageCursor, type UserProfileCreateParams as UserProfileCreateParams, type UserProfileRetrieveParams as UserProfileRetrieveParams, type UserProfileUpdateParams as UserProfileUpdateParams, type UserProfileListParams as UserProfileListParams, type UserProfileDeleteParams as UserProfileDeleteParams, };
    export { Organization as Organization, type OrganizationInfo as OrganizationInfo, type OrganizationRole as OrganizationRole, };
    export { Beta as Beta, type AnthropicBeta as AnthropicBeta, type BetaAPIError as BetaAPIError, type BetaAuthenticationError as BetaAuthenticationError, type BetaBillingError as BetaBillingError, type BetaCurrency as BetaCurrency, type BetaError as BetaError, type BetaErrorResponse as BetaErrorResponse, type BetaGatewayTimeoutError as BetaGatewayTimeoutError, type BetaInvalidRequestError as BetaInvalidRequestError, type BetaMonetaryAmount as BetaMonetaryAmount, type BetaNotFoundError as BetaNotFoundError, type BetaOverloadedError as BetaOverloadedError, type BetaPermissionError as BetaPermissionError, type BetaRateLimitError as BetaRateLimitError, };
    export type APIErrorObject = API.APIErrorObject;
    export type AuthenticationError = API.AuthenticationError;
    export type BillingError = API.BillingError;
    export type ErrorObject = API.ErrorObject;
    export type ErrorResponse = API.ErrorResponse;
    export type ErrorType = API.ErrorType;
    export type GatewayTimeoutError = API.GatewayTimeoutError;
    export type InvalidRequestError = API.InvalidRequestError;
    export type NotFoundError = API.NotFoundError;
    export type OverloadedError = API.OverloadedError;
    export type PermissionError = API.PermissionError;
    export type RateLimitError = API.RateLimitError;
}
//# sourceMappingURL=client.d.mts.map